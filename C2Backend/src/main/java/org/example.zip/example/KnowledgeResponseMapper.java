package org.example;


import org.neo4j.driver.Record;

import java.util.ArrayList;
import java.util.List;

public class KnowledgeResponseMapper {

    @SuppressWarnings("unchecked")
    public static KnowledgeQueryResponse fromDbResponse(DbResponse dbResponse) {
        Object rawResult = dbResponse.getResult();
        List<KnowledgePoint> points = new ArrayList<>();

        if (rawResult instanceof List<?> list && !list.isEmpty() && list.get(0) instanceof Record) {
            for (Record record : (List<Record>) list) {
                KnowledgePoint kp = new KnowledgePoint();
                kp.setId(record.get("kp").get("id").asString(""));
                kp.setName(record.get("kp").get("name").asString(""));
                kp.setContent(record.get("kp").get("content").asString(""));
                points.add(kp);
            }
        }

        return new KnowledgeQueryResponse(
                dbResponse.getCorrelationId(),
                dbResponse.isSuccess(),
                points,
                "knowledge_query_component"
        );
    }
}

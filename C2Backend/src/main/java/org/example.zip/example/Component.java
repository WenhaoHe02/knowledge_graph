package org.example;


public interface Component {
    String getComponentId();

    ApiRequest receiveFromFront();

    void sendToManager(DbRequest dbRequest);

    DbResponse receiveFromManager();

    boolean sendToFront(ApiResponse response);

    void process();
}

